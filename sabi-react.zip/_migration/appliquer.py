#!/usr/bin/env python3
"""Applique le projet React/Vite (dossier _nouveau/) dans le dépôt courant, SUR UNE BRANCHE,
sans jamais toucher à la branche principale. Lancé par .github/workflows/migrer-react.yml."""
import os, re, json, shutil, glob, sys

NOUVEAU = "_nouveau"
log = []
def dire(m): print(m); log.append(m)

# 1) Sauvegarde de l'ancien index.html (jamais supprimé, juste rangé)
if os.path.exists("index.html"):
    os.makedirs("ancien", exist_ok=True)
    shutil.move("index.html", "ancien/index.html")
    dire("Ancien index.html rangé dans ancien/index.html")

# 2) Fichiers statiques de la racine -> public/ (copiés tels quels dans dist/ par Vite)
os.makedirs("public", exist_ok=True)
EXT = {".png", ".jpg", ".jpeg", ".svg", ".ico", ".webp", ".gif", ".webmanifest", ".json", ".txt", ".xml", ".html"}
EXACT = {"sw.js", "firebase-messaging-sw.js", "_headers", "_redirects", "manifest.json", "assetlinks.json"}
NE_PAS_TOUCHER = {"package.json", "package-lock.json", "tsconfig.json", "capacitor.config.json", "vite.config.mjs", "LISEZMOI.txt"}
deplaces = []
for nom in sorted(os.listdir(".")):
    if not os.path.isfile(nom) or nom in NE_PAS_TOUCHER or nom.startswith("."): continue
    if nom == "sabi-react.zip": continue
    if nom in EXACT or os.path.splitext(nom)[1].lower() in EXT:
        if not os.path.exists(os.path.join("public", nom)):
            shutil.move(nom, os.path.join("public", nom)); deplaces.append(nom)
for d in ("icons", ".well-known", "assets", "images", "img"):
    if os.path.isdir(d) and not os.path.exists(os.path.join("public", d)):
        shutil.move(d, os.path.join("public", d)); deplaces.append(d + "/")
dire("Déplacés vers public/ : " + (", ".join(deplaces) or "(rien)"))

# 3) Copie du nouveau projet
if os.path.isdir("src"): shutil.rmtree("src")
shutil.copytree(os.path.join(NOUVEAU, "src"), "src")
for f in ("index.html", "vite.config.mjs", "LISEZMOI-REACT.md"):
    shutil.copy(os.path.join(NOUVEAU, f), f)
if os.path.isdir(os.path.join(NOUVEAU, ".github")):
    shutil.copytree(os.path.join(NOUVEAU, ".github"), ".github", dirs_exist_ok=True)
dire("Copié : src/, index.html, vite.config.mjs, workflows")

# 4) package.json : on FUSIONNE (les plugins Capacitor et autres dépendances existantes sont gardés)
n = json.load(open(os.path.join(NOUVEAU, "package.json")))
o = {}
if os.path.exists("package.json"):
    try: o = json.load(open("package.json"))
    except Exception: o = {}
o.setdefault("name", n["name"]); o.setdefault("version", n["version"]); o["private"] = True
o["scripts"] = {**o.get("scripts", {}), **n["scripts"]}
for sect in ("dependencies", "devDependencies"):
    o[sect] = {**o.get(sect, {}), **{k: v for k, v in n.get(sect, {}).items() if k not in o.get(sect, {}) or k in ("react", "react-dom")}}
if o.get("type") == "module":
    dire("ATTENTION : package.json a \"type\": \"module\" ; les fonctions Netlify en require() pourraient casser.")
json.dump(o, open("package.json", "w"), indent=2, ensure_ascii=False); open("package.json", "a").write("\n")
if os.path.exists("package-lock.json"):
    os.remove("package-lock.json"); dire("package-lock.json supprimé (sera régénéré par Netlify)")
dire("package.json fusionné (react, react-dom, vite ajoutés)")

# 5) netlify.toml : publier "dist" avec "npx vite build" (le reste du fichier est conservé)
cmd = 'command = "npx vite build"'; pub = 'publish = "dist"'
s = open("netlify.toml", encoding="utf-8").read() if os.path.exists("netlify.toml") else ""
m = re.search(r"^\[build\][ \t]*\r?$", s, re.M)
if m:
    fin = re.search(r"^\[", s[m.end():], re.M)
    fin_sec = m.end() + (fin.start() if fin else len(s) - m.end())
    section = s[m.end():fin_sec]
    section = re.sub(r"^[ \t]*(publish|command)[ \t]*=.*\r?\n?", "", section, flags=re.M)
    s = s[:m.end()] + "\n  " + pub + "\n  " + cmd + section + s[fin_sec:]
else:
    s = s.rstrip("\n") + ("\n\n" if s.strip() else "") + "[build]\n  " + pub + "\n  " + cmd + "\n"
open("netlify.toml", "w", encoding="utf-8").write(s)
dire("netlify.toml : publish = dist, command = npx vite build")

# 6) .gitignore
gi = open(".gitignore").read() if os.path.exists(".gitignore") else ""
for l in ("node_modules", "dist"):
    if not re.search(r"^/?" + l + r"/?\s*$", gi, re.M): gi = gi.rstrip("\n") + ("\n" if gi else "") + l + "\n"
open(".gitignore", "w").write(gi)

# 7) Capacitor : le dossier web devient "dist"
for f in glob.glob("capacitor.config.*"):
    t = open(f, encoding="utf-8").read()
    t2 = re.sub(r"""(["']?webDir["']?\s*:\s*)["'][^"']*["']""", r'\1"dist"', t)
    if t2 != t: open(f, "w", encoding="utf-8").write(t2); dire(f + " : webDir = dist")

shutil.rmtree(NOUVEAU, ignore_errors=True)
if os.path.exists("sabi-react.zip"): os.remove("sabi-react.zip")
open("MIGRATION-REACT.log", "w", encoding="utf-8").write("\n".join(log) + "\n")
dire("Terminé.")
