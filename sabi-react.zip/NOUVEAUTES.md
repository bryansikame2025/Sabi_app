# Nouveautés intégrées dans ce projet

- **Accueil redessiné** (`src/tabs/accueil/`, 18 fichiers) : héros avec points en grand + niveau, barre de niveau segmentée,
  rappel du jour discret et fermable, cartes avec plus de marge, texte secondaire plus clair, glassmorphism.
- **8 thèmes** : Sombre et Clair (inchangés) + Verre (fond animé + verre dépoli), Aurore, Dune, Savane, Ardoise, Néon
  (héros « anneau Score Actuel »). Rubrique « Thèmes » dans le menu, juste sous « Notifications ».
  Fichiers : `src/themes.js` (données des thèmes), `src/theme.js` (registre + application), `src/components/ThemePicker.jsx`,
  `src/styles/accueil.css`. Ajouter un thème = une entrée dans `src/themes.js`.
- **Puce de points dans l'en-tête** (`src/components/PointsChip.jsx`) : le « +N » s'affiche dans la puce ; le toast « +N points » est supprimé.
- **Correctif du toast** (`sabi.css` : `animation … forwards`) : plus de décalage hors-centre.
- **Icône « x »** corrigée (`Icon.js`).
Fichiers modifiés : `SabiApp.js`, `components/MenuLateral.js`, `components/Icon.js`, `main.js`, `theme.js`, `styles/sabi.css`, `tabs/AccueilTab.js`.
